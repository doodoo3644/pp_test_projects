<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Ose Tools - Login</title>

</head>

<body>


        <center>
         <form action='login.php' method="post">
          <p>
           <br />
           <h2>Welcome to OSE Tools</h2>
          </p>
          <p>
           <table border="0" cellspacing="0">
           <tr>
            <td>Username:</td>
            <td><input type="text" name="username"></td>
           </tr>
           <tr>
            <td>Password:</td>
            <td><input type="password" name="password"></td>
           </tr>
           <tr align="center">
            <td colspan="2">
             <input type="submit" value="     Login     ">
            </td>
           </tr>
          </table>
         </p>
        </form>
       </center>






</body>

</html>
