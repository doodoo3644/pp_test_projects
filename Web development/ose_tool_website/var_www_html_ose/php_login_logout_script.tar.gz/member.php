<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title></title>

</head>

<body>


<?php

session_start();

if ($_SESSION['username']) {

   echo "Welcome, " .$_SESSION['username']. "!<br/>";
   echo "<a href='logout.php'>Logout</a>";

} else {
   
   die (" <br/>
       <center>
        You must be logged in!
        <br/>
        <a href='https://10.20.28.115/ose'>Login</a>
       </center>
    ");  
   
 }

?>





</body>

</html>
