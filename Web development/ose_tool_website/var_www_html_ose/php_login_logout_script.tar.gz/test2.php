<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Your Page Title</title>
<meta http-equiv="REFRESH" content="0;url=https://10.20.28.115/ose/tools/login.php"></HEAD>
<BODY>
Optional page text here.
</BODY>
</HTML>

